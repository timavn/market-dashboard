import json
import boto3
import csv
from datetime import datetime
from decimal import Decimal
import os
from io import StringIO

s3_client = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')

# DynamoDB table names from environment variables
PORTFOLIO_TABLE = os.environ.get('PORTFOLIO_TABLE', 'PortfolioSnapshots')
HOLDINGS_TABLE = os.environ.get('HOLDINGS_TABLE', 'Holdings')
LOGS_TABLE = os.environ.get('LOGS_TABLE', 'ProcessingLogs')

def lambda_handler(event, context):
    """
    Lambda function to process Schwab CSV files uploaded to S3
    Triggered by S3 PUT events
    """
    bucket = None
    key = None

    try:
        # Get bucket and key from S3 event
        bucket = event['Records'][0]['s3']['bucket']['name']
        key = event['Records'][0]['s3']['object']['key']

        print(f"Processing file: {bucket}/{key}")

        # Download CSV from S3
        response = s3_client.get_object(Bucket=bucket, Key=key)
        csv_content = response['Body'].read().decode('utf-8')

        # Parse Schwab CSV
        portfolio_data = parse_schwab_csv(csv_content)

        # Store in DynamoDB
        snapshot_id = store_portfolio_snapshot(portfolio_data)
        store_holdings(snapshot_id, portfolio_data['holdings'])

        # Log successful processing
        log_processing(bucket, key, 'SUCCESS', snapshot_id)

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'CSV processed successfully',
                'snapshotId': snapshot_id,
                'holdingsCount': len(portfolio_data['holdings'])
            })
        }

    except Exception as e:
        print(f"Error processing CSV: {str(e)}")
        if bucket and key:
            log_processing(bucket, key, 'FAILED', error=str(e))
        raise e


def parse_schwab_csv(csv_content):
    """
    Parse Schwab CSV format and extract portfolio data
    Based on csvParser.js logic
    """
    lines = csv_content.strip().split('\n')

    # Find header row (contains "Symbol" and "Description")
    header_index = -1
    for i, line in enumerate(lines):
        if 'Symbol' in line and 'Description' in line:
            header_index = i
            break

    if header_index == -1:
        raise ValueError("Could not find header row in CSV")

    # Parse CSV data
    csv_data = '\n'.join(lines[header_index:])
    reader = csv.DictReader(StringIO(csv_data))

    holdings = []
    total_value = Decimal('0')
    asset_allocation = {}

    for row in reader:
        symbol = row.get('Symbol', '').strip()

        # Skip account totals and invalid rows
        if not symbol or symbol.startswith('Account Total') or symbol == 'Totals':
            continue

        # Parse numerical values
        quantity = parse_number(row.get('Quantity', '0'))
        price = parse_number(row.get('Price', '0'))
        market_value = parse_number(row.get('Market Value', '0'))
        cost_basis = parse_number(row.get('Cost Basis Total', '0'))
        gain_loss = parse_number(row.get('Gain/Loss $', '0'))
        gain_loss_pct = parse_number(row.get('Gain/Loss %', '0'))

        # Asset type mapping
        asset_type = row.get('Type', 'Unknown')
        asset_class = map_asset_type(asset_type)

        holding = {
            'symbol': symbol,
            'description': row.get('Description', '').strip(),
            'quantity': quantity,
            'price': price,
            'marketValue': market_value,
            'costBasis': cost_basis,
            'gainLoss': gain_loss,
            'gainLossPercent': gain_loss_pct,
            'assetType': asset_type,
            'assetClass': asset_class
        }

        holdings.append(holding)
        total_value += Decimal(str(market_value))

        # Aggregate asset allocation
        if asset_class in asset_allocation:
            asset_allocation[asset_class] += market_value
        else:
            asset_allocation[asset_class] = market_value

    # Calculate percentages for asset allocation
    asset_allocation_pct = {}
    if total_value > 0:
        for asset_class, value in asset_allocation.items():
            percentage = (Decimal(str(value)) / total_value) * 100
            asset_allocation_pct[asset_class] = percentage

    # Calculate summary metrics
    total_gain_loss = sum(h['gainLoss'] for h in holdings)
    total_cost_basis = sum(h['costBasis'] for h in holdings)
    total_gain_loss_pct = (total_gain_loss / total_cost_basis * 100) if total_cost_basis > 0 else Decimal('0')

    return {
        'holdings': holdings,
        'summary': {
            'totalValue': total_value,
            'totalGainLoss': total_gain_loss,
            'totalGainLossPercent': total_gain_loss_pct,
            'positionCount': len(holdings),
            'totalCostBasis': total_cost_basis
        },
        'assetAllocation': asset_allocation_pct
    }


def parse_number(value):
    """Parse dollar amounts and percentages from Schwab CSV format"""
    if not value or value == '--':
        return Decimal('0')

    # Remove $, commas, and % signs
    cleaned = str(value).replace('$', '').replace(',', '').replace('%', '').strip()

    # Handle parentheses for negative numbers
    if cleaned.startswith('(') and cleaned.endswith(')'):
        cleaned = '-' + cleaned[1:-1]

    try:
        return Decimal(cleaned)
    except (ValueError, Exception):
        return Decimal('0')


def map_asset_type(schwab_type):
    """Map Schwab asset types to our asset classes"""
    mapping = {
        'ETFs & Closed End Funds': 'Equities',
        'Equity': 'Equities',
        'Cash and Money Market': 'Cash',
        'Fixed Income': 'Fixed Income',
        'Options': 'Derivatives',
        'Mutual Funds': 'Equities'
    }
    return mapping.get(schwab_type, 'Other')


def store_portfolio_snapshot(portfolio_data):
    """Store portfolio snapshot in DynamoDB"""
    table = dynamodb.Table(PORTFOLIO_TABLE)

    snapshot_id = datetime.utcnow().strftime('%Y%m%d_%H%M%S')
    timestamp = datetime.utcnow().isoformat()

    item = {
        'snapshotId': snapshot_id,
        'timestamp': timestamp,
        'summary': portfolio_data['summary'],
        'assetAllocation': portfolio_data['assetAllocation'],
        'holdingsCount': len(portfolio_data['holdings'])
    }

    table.put_item(Item=item)
    print(f"Stored portfolio snapshot: {snapshot_id}")

    return snapshot_id


def store_holdings(snapshot_id, holdings):
    """Store individual holdings in DynamoDB"""
    table = dynamodb.Table(HOLDINGS_TABLE)

    with table.batch_writer() as batch:
        for holding in holdings:
            # Create composite holdingId as partition key
            holding_id = f"{snapshot_id}#{holding['symbol']}"

            item = {
                'holdingId': holding_id,
                'snapshotId': snapshot_id,
                **holding  # This already contains symbol and all other fields
            }
            batch.put_item(Item=item)

    print(f"Stored {len(holdings)} holdings")


def log_processing(bucket, key, status, snapshot_id=None, error=None):
    """Log processing attempt in DynamoDB"""
    try:
        table = dynamodb.Table(LOGS_TABLE)

        timestamp = datetime.utcnow().isoformat()
        item = {
            'logId': f"{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}_{key.replace('/', '_')}",
            'timestamp': timestamp,
            'bucket': bucket,
            'key': key,
            'status': status,
        }

        if snapshot_id:
            item['snapshotId'] = snapshot_id
        if error:
            item['errorMessage'] = str(error)

        table.put_item(Item=item)
        print(f"Logged processing: {status}")
    except Exception as e:
        # Don't fail the whole function if logging fails
        print(f"Warning: Could not log to ProcessingLogs: {str(e)}")


